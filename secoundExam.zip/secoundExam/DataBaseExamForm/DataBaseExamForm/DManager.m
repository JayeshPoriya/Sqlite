//
//  DManager.m
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import "DManager.h"
#import "AppDelegate.h"
#import "AllStringclass.h"

@implementation DManager

-(NSMutableArray *)Alldata
{
    myarray = [[NSMutableArray alloc]init];
    sqlite3_stmt *select_exceptions=nil;
    NSString *str_exceptions=@"select * from jptable"; 
    const char *sql=[str_exceptions UTF8String];
    sqlite3 *db =[AppDelegate getNewDBConnection];  //open databasa
    if(sqlite3_prepare_v2(db, sql,-1, &select_exceptions,NULL)==SQLITE_OK)
    {
        NSString *f_Name,*l_Name,*Gender,*DoB,*Country;
        
        NSInteger ab=0;
        
        while(sqlite3_step(select_exceptions)==SQLITE_ROW)
        {
            AllStringclass *obj = [[AllStringclass alloc]init];
            
            
            f_Name=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,1) encoding:NSUTF8StringEncoding];
            
            l_Name=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,2) encoding:NSUTF8StringEncoding];
            Gender=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,3) encoding:NSUTF8StringEncoding];
            DoB=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,4) encoding:NSUTF8StringEncoding];
            Country=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,5) encoding:NSUTF8StringEncoding];
            NSLog(@"%@",[NSString stringWithFormat:@"%d", DoB]);
            obj.str_fname = f_Name;
            obj.str_lname = l_Name;
            obj.str_gen = Gender;
            obj.str_dateofbrith = DoB;
            obj.str_con = Country;
                     [myarray addObject:obj];
            ab++;
            
            
        }
        
    }
    else
    {
        NSLog(@"Could not Compile Properly.....");
    }
    sqlite3_finalize(select_exceptions);
    sqlite3_close(db); 
    
    NSLog(@"All User From DBManager %@",myarray);
    
    return myarray;
}

-(void)inserttodatabse:(NSString *)firstname:(NSString *)lastname:(NSString *)gender:(NSString *)dob:(NSString *)country
{
    
    sqlite3 *db =[AppDelegate getNewDBConnection];  
    sqlite3_stmt *compiledStatement;
    
    NSString *query = nil;
    query = [NSString stringWithFormat:@"insert into jptable(firstname,lastname,gender,dob,country) values('%@','%@','%@','%@','%@')",firstname,lastname,gender,dob,country];
    NSLog(@"Query.....%@",query);
    
        
    
       if(sqlite3_prepare_v2(db, [query UTF8String], -1, &compiledStatement, NULL) == SQLITE_OK) 
    {   
        if(SQLITE_DONE != sqlite3_step(compiledStatement))
        {
            NSLog( @"Error while inserting data: '%s'", sqlite3_errmsg(db));
        }
        else 
        {
            int a;
            a=sqlite3_last_insert_rowid(db);
            NSLog(@"New data inserted with row_id %d",a);
            
        }
        sqlite3_reset(compiledStatement);       
    }   
    else
    {
        NSLog( @"Error while inserting '%s'", sqlite3_errmsg(db));
    }
    
    
    sqlite3_finalize(compiledStatement);
    sqlite3_close(db);  
}


-(void)DeleteDatabase:(NSString *)firstname
{
    sqlite3_stmt *deleteStmt=nil;
    
    NSString *strDeletePin;
    strDeletePin=[NSString stringWithFormat:@"delete from jptable where firstname = '%@'",firstname];
    
    const char *sql=[strDeletePin UTF8String];
    sqlite3 *db = [AppDelegate getNewDBConnection];
    
    if(sqlite3_prepare_v2(db,sql,-1,&deleteStmt,NULL)==SQLITE_OK)
    {
        if(sqlite3_step(deleteStmt)==SQLITE_DONE)
        {
            NSLog(@"User Deleted Successfully.....");
        }
        else
        {
            NSLog(@"Problem in Deleting User....");
        }
    }
    else
    {
        NSLog(@"Problem While compiling delete User statement..");
    }
    
    sqlite3_finalize(deleteStmt);
    sqlite3_close(db);
}


-(void)updateRow:(NSString *)firstNamesbefore:(NSString *)firstnamereg:(NSString *)lastNames:(NSString *)genders:(NSString *)dobs:(NSString *)countrys
{
    
    sqlite3 *db =[AppDelegate getNewDBConnection]; 
    NSString *query = nil;
    NSLog(@"FirstName Before...%@",firstNamesbefore);
    NSLog(@"FirstnameAfter...%@",firstnamereg);
    NSLog(@"lastName...%@",lastNames);
    NSLog(@"Genders...%@",genders);
    NSLog(@"Dobs...%@",dobs);
    NSLog(@"Country...%@",countrys);
   query = [NSString stringWithFormat:@"update jptable set firstname = '%@', lastname= '%@', gender= '%@', dob = '%@', country = '%@' where firstname= '%@'",firstnamereg,lastNames,genders,dobs,countrys,firstNamesbefore];
    
    NSLog(@"Query..%@",query);
    sqlite3_stmt *compiledStatement;
 
    
    if(sqlite3_prepare_v2(db, [query UTF8String], -1, &compiledStatement, NULL) == SQLITE_OK) 
    {   
        if(SQLITE_DONE != sqlite3_step(compiledStatement))
        {
            NSLog( @"Error while updating data: '%s'", sqlite3_errmsg(db));
        }
        else 
        {
            int a;
            a=sqlite3_last_insert_rowid(db);
            NSLog(@"New data updated with row_id %d",a);
            
        }
        sqlite3_reset(compiledStatement);       
    }else
    {
        NSLog( @"Error while updating '%s'", sqlite3_errmsg(db));
    }
    sqlite3_finalize(compiledStatement);
    
    sqlite3_close(db);  
    
}


-(NSMutableArray *) SearchesRows:(NSString *)firstnamess:(NSString *)lastnamess
{
    NSMutableArray *arr= [[NSMutableArray alloc]init];
    sqlite3_stmt *select_exceptions=nil;

    NSString *str_exceptions=[NSString stringWithFormat:@"SELECT * FROM jptable WHERE firstname LIKE '%%%@%%' or lastname LIKE '%%%@%%'",firstnamess,lastnamess]; 
    NSLog(@"query for search %@",str_exceptions);
    
    const char *sql=[str_exceptions UTF8String];
    sqlite3 *db =[AppDelegate getNewDBConnection];  
    
    if(sqlite3_prepare_v2(db, sql,-1, &select_exceptions,NULL)==SQLITE_OK)
    {
        NSString *f_Name,*l_Name,*Gender,*DoB,*Country;
        
        NSInteger ab=0;
        
        while(sqlite3_step(select_exceptions)==SQLITE_ROW)
        {
            AllStringclass *obj = [[AllStringclass alloc]init];
            
            
            f_Name=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,1) encoding:NSUTF8StringEncoding];
            
            l_Name=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,2) encoding:NSUTF8StringEncoding];
            Gender=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,3) encoding:NSUTF8StringEncoding];
            DoB=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,4) encoding:NSUTF8StringEncoding];
            Country=[NSString stringWithCString:(char *)sqlite3_column_text(select_exceptions,5) encoding:NSUTF8StringEncoding];
            NSLog(@"....%@...",f_Name);
            obj.str_fname = f_Name;
            obj.str_lname = l_Name;
            obj.str_gen = Gender;
            obj.str_dateofbrith = DoB;
            obj.str_con = Country;
            
            [arr addObject:obj];
            ab++;     
        }
    }
    else
    {
        NSLog(@"Could not Compile Properly.....");
    }
    sqlite3_finalize(select_exceptions);
    sqlite3_close(db); 
    return arr;
}



@end
