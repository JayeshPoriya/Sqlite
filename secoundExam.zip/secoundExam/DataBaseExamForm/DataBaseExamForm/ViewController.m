//
//  ViewController.m
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import "ViewController.h"
#import "SecoundScreenInfo.h"
#import "AllStringclass.h"
@implementation ViewController
@synthesize btn_male;
@synthesize btn_female;
@synthesize btn_dob;
@synthesize btn_country;
@synthesize btn_insert;
@synthesize btn_update;
@synthesize btn_delete;
@synthesize tx_firstname;
@synthesize tx_lastname;
@synthesize lbl_firstname;
@synthesize lbl_lastname;
@synthesize lbl_gender;
@synthesize lbl_dob;
@synthesize lbl_country;
@synthesize lblselectcyourountry;
@synthesize lblselectyourdate;
@synthesize strfirstname;
@synthesize strlastname;
@synthesize strdob;
@synthesize strgender;
@synthesize strcountry;
@synthesize btn_RowId;
@synthesize strselectyourdate;
@synthesize strselectyourcountry;


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

	// Do any additional setup after loading the view, typically from a nib.
    
    Scroll.contentSize = CGSizeMake(0, self.view.bounds.size.height * 2);    
    [self.view addSubview:Scroll]; 
    NSLog(@"gender >>%@",strgender);
    //strgender = @"Male";
    // SET KEYBOURD
    UIToolbar * keyboardToolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    
    keyboardToolBar.barStyle = UIBarStyleDefault;
    [keyboardToolBar setItems: [NSArray arrayWithObjects:
                                [[UIBarButtonItem alloc]initWithTitle:@"Previous" style:UIBarButtonItemStyleBordered target:self action:@selector(previousTextField)],
                                
                                [[UIBarButtonItem alloc] initWithTitle:@"Next" style:UIBarButtonItemStyleBordered target:self action:@selector(nextTextField)],
                                [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                                [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(resignKeyboard)],
                                nil]];
    tx_firstname.inputAccessoryView = keyboardToolBar;
    tx_lastname.inputAccessoryView = keyboardToolBar;
    
    lblselectyourdate.text = strselectyourdate ;
    lblselectcyourountry.text = strselectyourcountry ;
    NSLog(@"Country...%@",strselectyourcountry);
    
    if ([strgender isEqualToString:@"Male"]) {
        
        [btn_male setImage: [UIImage imageNamed:@"Radio_button_on.png"]forState:UIControlStateNormal];
        [btn_female setImage: [UIImage imageNamed:@"Radio_button_off.png"]forState:UIControlStateNormal];

    }
    else
    {
        
        [btn_female setImage: [UIImage imageNamed:@"Radio_button_on.png"]forState:UIControlStateNormal];
        [btn_male setImage: [UIImage imageNamed:@"Radio_button_off.png"]forState:UIControlStateNormal];
 
    }
    
    tx_firstname.text = strfirstname;
    tx_lastname.text = strlastname;
    strprevName = tx_firstname.text;
}

- (void)viewDidUnload
{
    [self setLbl_firstname:nil];
    [self setLbl_lastname:nil];
    [self setLbl_gender:nil];
    [self setLbl_dob:nil];
    [self setLbl_country:nil];
    [self setTx_firstname:nil];
    [self setTx_lastname:nil];
    [self setBtn_male:nil];
    [self setBtn_female:nil];
    [self setBtn_dob:nil];
    [self setBtn_country:nil];
    [self setBtn_insert:nil];
    [self setLblselectcyourountry:nil];
    [self setLblselectyourdate:nil];
    [self setBtn_update:nil];
    [self setBtn_delete:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)clickmale:(id)sender 
{
   
    [btn_male setImage: [UIImage imageNamed:@"Radio_button_on.png"]forState:UIControlStateNormal];
    [btn_female setImage: [UIImage imageNamed:@"Radio_button_off.png"]forState:UIControlStateNormal];
    strgender = @"Male";
    

}

- (IBAction)clickfemale:(id)sender 
{
   
    [btn_female setImage: [UIImage imageNamed:@"Radio_button_on.png"]forState:UIControlStateNormal];
    [btn_male setImage: [UIImage imageNamed:@"Radio_button_off.png"]forState:UIControlStateNormal];
    strgender = @"Female";

}

- (IBAction)clickdob:(id)sender 
{
    
    datepicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 250, self.view.frame.size.width, 30)];
    df = [[NSDateFormatter alloc] init];
    [datepicker setDatePickerMode:UIDatePickerModeDate];
    [df setDateFormat:@"MM-dd-yyyy"];  
    datepicker.hidden = YES;
    [self.view addSubview:datepicker];
    
    datepicker.hidden = NO;
    pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 220,self.view.bounds.size.width,260)];
    [pickerToolbar sizeToFit];
    pickerToolbar.barStyle = UIBarStyleBlackTranslucent;
    [datepicker setMaximumDate:[NSDate dateWithTimeIntervalSinceNow:-24*60*60]];
    NSMutableArray *barItems = [[NSMutableArray alloc] init];
    doneBtn = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(done_clicked)];
    [barItems addObject:doneBtn];
    [pickerToolbar setItems:barItems animated:YES];
    [self.view addSubview:pickerToolbar];
}

-(void)done_clicked
{
    [datepicker setHidden:YES];
    [pickerToolbar setHidden:YES];
    strselectyourdate = [df stringFromDate:datepicker.date];
    [lblselectyourdate setText:strselectyourdate];  
}


- (IBAction)clickcountry:(id)sender 
{
    countryarray = [[NSArray alloc]initWithObjects:@"surat",@"Rajkot",@"Ahmedabad",@"junagdh",@"Amreli", nil];
    pickerview = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 250, self.view.frame.size.width, 0)];
    [pickerview setShowsSelectionIndicator:YES];
    pickerview.delegate = self;
    pickerview.dataSource = self;
    [self.view addSubview:pickerview]; 
    
   simplepickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 245,self.view.bounds.size.width,250)];
    [simplepickerToolbar sizeToFit];
    simplepickerToolbar.barStyle = UIBarStyleBlackTranslucent;
    NSMutableArray *barItem = [[NSMutableArray alloc] init];
    
    simpledoneBtn = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(simpledone_clicked)];
    [barItem addObject:simpledoneBtn];
    [simplepickerToolbar setItems:barItem animated:YES];
    [self.view addSubview:simplepickerToolbar];
}

-(void)simpledone_clicked
{
    [pickerview setHidden:YES];
    [simplepickerToolbar setHidden:YES];
    

    [lblselectcyourountry setText:strselectyourcountry];
  }

- (IBAction)clickinsert:(id)sender 
{
    NSLog(@"%@",tx_firstname.text);
    NSLog(@"%@",tx_lastname.text);
      
    if ([tx_firstname.text isEqualToString:@""] || [tx_lastname.text isEqualToString: @""] || [lblselectcyourountry.text isEqualToString:@""] || [lblselectyourdate.text isEqualToString:@""]) 
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" 
                                                        message:@"First Fill all Data" 
                                                       delegate:nil 
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        
    }
   else
    {

    
            datamanagerobject = [[DManager alloc]init];
            [datamanagerobject inserttodatabse:tx_firstname.text :tx_lastname.text :strgender :strselectyourdate :strselectyourcountry];
        
            NSLog(@"%@",tx_firstname.text);
            NSLog(@"%@",tx_lastname.text);
            NSLog(@"%@",strgender);
            NSLog(@"%@",strselectyourdate);
            NSLog(@"%@",strselectyourcountry);
            
            SecoundScreenInfo *sc =[[SecoundScreenInfo alloc]init];
            [self.navigationController pushViewController:sc animated:YES];
    }
   
}

- (IBAction)clickupadte:(id)sender 
{
    
    
    if ([tx_firstname.text isEqualToString:@""] || [tx_lastname.text isEqualToString: @""]) 
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" 
                                                        message:@"First Fill all Data" 
                                                       delegate:nil 
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        
    }
    else
    {
    strfirstname = tx_firstname.text;
    strlastname = tx_lastname.text;
    datamanagerobject = [[DManager alloc]init];
    
    [datamanagerobject updateRow:strprevName :strfirstname :strlastname :strgender :strselectyourdate :strselectyourcountry];
        NSLog(@"STRDOB...%@",strselectyourdate);
        NSLog(@"STRCOUNTRY...%@",strselectyourcountry);
      
        
    [self.navigationController pushViewController:[[SecoundScreenInfo alloc]init] animated:YES];
    }
}
- (IBAction)clickdelete:(id)sender 
{
   
    
    if ([tx_firstname.text isEqualToString:@""] || [tx_lastname.text isEqualToString: @""]) 
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" 
                                                        message:@"First Fill all Data" 
                                                       delegate:nil 
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        
    }
    else
    {

    datamanagerobject = [[DManager alloc]init];
    [datamanagerobject DeleteDatabase:tx_firstname.text];
    [self.navigationController pushViewController:[[SecoundScreenInfo alloc]init] animated:YES];

    }
}

- (IBAction)ckeardclicked:(id)sender
{

    tx_firstname.text = @"";
    tx_lastname.text = @"";
    [btn_male setImage: [UIImage imageNamed:@"Radio_button_on.png"]forState:UIControlStateNormal];
    [btn_female setImage: [UIImage imageNamed:@"Radio_button_off.png"]forState:UIControlStateNormal];
    lblselectyourdate.text = @"  ";
    lblselectcyourountry.text = @"  ";
       
}


- (IBAction)clicketoselectbtn:(id)sender 
{
    [self.navigationController pushViewController:[[SecoundScreenInfo alloc]init] animated:YES];
}


// Next and Previous Button in keyBourd

- (void)nextTextField
{
    
    
    if (tx_firstname)
    {
        
        [tx_firstname resignFirstResponder];
        [tx_lastname becomeFirstResponder];
        
    }
    
}

-(void)previousTextField
{
    
    if (tx_lastname) 
    {
        [tx_lastname resignFirstResponder];
        [tx_firstname becomeFirstResponder];
    }
    
    
}

-(void)resignKeyboard 
{
    
    [tx_firstname resignFirstResponder];
    [tx_lastname resignFirstResponder];
    
}

// Next and Previous Button in keyBourd Over


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [countryarray count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [countryarray objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    strselectyourcountry = [countryarray objectAtIndex:row];
            
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [tx_firstname resignFirstResponder];
    [tx_lastname resignFirstResponder];
    return YES;
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [tx_firstname resignFirstResponder];
    [tx_lastname resignFirstResponder];
}

@end
