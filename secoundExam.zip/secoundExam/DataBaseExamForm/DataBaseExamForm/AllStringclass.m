//
//  AllStringclass.m
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import "AllStringclass.h"

@implementation AllStringclass
@synthesize str_fname,str_lname,str_gen,str_dateofbrith,str_con,str_id;

@end
