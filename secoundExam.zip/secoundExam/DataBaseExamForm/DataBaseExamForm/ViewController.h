//
//  ViewController.h
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DManager.h"

@interface ViewController : UIViewController<UIScrollViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate>
{
    IBOutlet UIScrollView *Scroll;
    UIDatePicker * datepicker;
    UIPickerView * pickerview;
    UIBarButtonItem *doneBtn;
    UIBarButtonItem *simpledoneBtn;
    UIToolbar *pickerToolbar;
    UIToolbar *simplepickerToolbar;
    NSArray * countryarray;
    NSString * strselectyourcountry;
    NSString * strselectyourdate;
    NSDateFormatter *df;
    DManager *datamanagerobject;
    NSMutableArray *viewArray;
    NSString *strprevName;
 
 
}

-(void)done_clicked;
-(void)simpledone_clicked;
-(BOOL) textFieldShouldReturn:(UITextField *)textField;
@property (strong, nonatomic) IBOutlet NSString *strfirstname;
@property (strong, nonatomic) IBOutlet NSString *strlastname;
@property (strong, nonatomic) IBOutlet NSString *strgender;
@property (strong, nonatomic) IBOutlet NSString *strdob;
@property (strong, nonatomic) IBOutlet NSString *strcountry;
@property (strong, nonatomic) IBOutlet NSString *strselectyourcountry;
@property (strong, nonatomic) IBOutlet NSString *strselectyourdate;
//@property (nonatomic,assign) int varTempforbutton;




// All Lable object
@property (strong, nonatomic) IBOutlet UILabel *lbl_firstname;
@property (strong, nonatomic) IBOutlet UILabel *lbl_lastname;
@property (strong, nonatomic) IBOutlet UILabel *lbl_gender;
@property (strong, nonatomic) IBOutlet UILabel *lbl_dob;
@property (strong, nonatomic) IBOutlet UILabel *lbl_country;
@property (strong, nonatomic) IBOutlet UILabel *lblselectcyourountry;
@property (strong, nonatomic) IBOutlet UILabel *lblselectyourdate;

// All TextFiled Object
@property (strong, nonatomic) IBOutlet UITextField *tx_firstname;
@property (strong, nonatomic) IBOutlet UITextField *tx_lastname;
@property (strong, nonatomic) IBOutlet UITextField *btn_RowId;

//All Button Object
@property (strong, nonatomic) IBOutlet UIButton *btn_male;
@property (strong, nonatomic) IBOutlet UIButton *btn_female;
@property (strong, nonatomic) IBOutlet UIButton *btn_dob;
@property (strong, nonatomic) IBOutlet UIButton *btn_country;
@property (strong, nonatomic) IBOutlet UIButton *btn_insert;
@property (strong, nonatomic) IBOutlet UIButton *btn_update;
@property (strong, nonatomic) IBOutlet UIButton *btn_delete;

//All Button Action

- (IBAction)clickmale:(id)sender;
- (IBAction)clickfemale:(id)sender;
- (IBAction)clickdob:(id)sender;
- (IBAction)clickcountry:(id)sender;
- (IBAction)clickinsert:(id)sender;
- (IBAction)clickupadte:(id)sender;
- (IBAction)clickdelete:(id)sender;
- (IBAction)ckeardclicked:(id)sender;

- (IBAction)clicketoselectbtn:(id)sender;

@end
