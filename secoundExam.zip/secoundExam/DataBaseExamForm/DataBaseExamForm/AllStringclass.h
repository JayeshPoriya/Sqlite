//
//  AllStringclass.h
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AllStringclass : NSObject
    
@property (strong, nonatomic) NSString *str_fname;
@property (strong, nonatomic) NSString *str_lname;
@property (strong, nonatomic) NSString *str_gen;
@property (strong, nonatomic) NSString *str_dateofbrith;
@property (strong, nonatomic) NSString *str_con;
@property (nonatomic,readonly) int str_id;

@end
