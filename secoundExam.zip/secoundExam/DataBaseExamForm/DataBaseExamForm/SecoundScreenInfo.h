//
//  SecoundScreenInfo.h
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DManager.h"

@interface SecoundScreenInfo : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
{
    IBOutlet UITableView *tableView;
    NSString * SecondFirstname;
    NSString * SecoundLastname, *country;
    DManager *datamanagerobject ;
}
@property (strong, nonatomic) IBOutlet UITextField *txsearch;

@property(nonatomic,retain)NSMutableArray *allArray;


@end
