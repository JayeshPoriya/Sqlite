//
//  CustomeCell.h
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomeCell : UITableViewCell

@end
