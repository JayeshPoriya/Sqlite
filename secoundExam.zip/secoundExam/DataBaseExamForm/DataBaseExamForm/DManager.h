//
//  DManager.h
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"

@interface DManager : NSObject
{
    sqlite3 *database;
    NSMutableArray * myarray;
}

-(NSMutableArray *)Alldata;
-(void)inserttodatabse:(NSString *)firstname:(NSString *)lastname:(NSString *)gender:(NSString *)dob:(NSString *)country;
-(void)DeleteDatabase:(NSString *)firstname;
-(NSMutableArray *) SearchesRows:(NSString *)firstnamess:(NSString *)lastnamess;

-(void)updateRow:(NSString *)firstNamesbefore:(NSString *)firstnamereg:(NSString *)lastNames:(NSString *)genders:(NSString *)dobs:(NSString *)countrys;


-(void)UpdateuserInfo:(NSString *)firstName :(NSString *)lastName:(NSString *)gender:(NSString *)dob:(NSString *)country:(int )userId;
-(void)openDatabase;

@end
