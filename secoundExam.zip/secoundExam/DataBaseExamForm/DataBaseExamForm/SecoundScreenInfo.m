//
//  SecoundScreenInfo.m
//  DataBaseExamForm
//
//  Created by Harshul Shah on 20/02/14.
//  Copyright (c) 2014 shah.harshul@yahoo.com. All rights reserved.
//

#import "SecoundScreenInfo.h"
#import "AllStringclass.h"
#import "CustomeCell.h"
#import "AppDelegate.h"
#import "ViewController.h"
#import "DManager.h"
@implementation SecoundScreenInfo
@synthesize txsearch;
@synthesize allArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
       self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
      // Do any additional setup after loading the view from its nib.
    datamanagerobject = [[DManager alloc]init];
    [allArray removeAllObjects];
    allArray = [datamanagerobject Alldata];
    [tableView reloadData];
    NSLog(@"All User Data from Second View  = %@",allArray);
    txsearch.delegate = self;
    [txsearch setText:@""];

}

- (void)viewDidUnload
{
   
    [self setTxsearch:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [allArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
 
    CustomeCell *cell =[[CustomeCell alloc]init];
    AllStringclass *allObj = [[AllStringclass alloc]init];
    
    allObj = [allArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = allObj.str_fname;
    //cell.textLabel.text = allObj.str_lname;
    
    return cell;

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    ViewController *vc =[[ViewController alloc]init];
    AllStringclass * allstr = [allArray objectAtIndex:indexPath.row];
    
    SecondFirstname = allstr.str_fname;
    SecoundLastname = allstr.str_lname;
    vc.strfirstname = allstr.str_fname;
    vc.strlastname  = allstr.str_lname;
    vc.strgender = allstr.str_gen;
    vc.strselectyourdate = allstr.str_dateofbrith;
    vc.strselectyourcountry = allstr.str_con;
    
    NSLog(@"%@...",allstr.str_fname);
    NSLog(@"%@...",allstr.str_lname);
    NSLog(@"%@...",allstr.str_gen);
    NSLog(@"%@...",allstr.str_dateofbrith);
    NSLog(@"%@...",allstr.str_con);
    [self.navigationController pushViewController:vc animated:YES];
   
}


- (IBAction)tfsearchEditingDidChanged:(id)sender 
{
    [allArray removeAllObjects];
    datamanagerobject = [[DManager alloc]init];
    if ([txsearch.text isEqualToString:@""]) 
    {
        allArray = [datamanagerobject Alldata];
        NSLog(@"count of all the data of arrmydata: %d",[allArray count]);
        [tableView reloadData];
    }
    else
    {
        allArray = [datamanagerobject SearchesRows:txsearch.text :txsearch.text];
        NSLog(@"count of allArray: %d",[allArray count]);
        [tableView reloadData];
    }
    
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField         
{
    [txsearch resignFirstResponder];
    return YES;
}


@end
